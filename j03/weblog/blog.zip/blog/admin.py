from django.contrib import admin
from .models import *

# Register your models here.
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ["title", "auther", "published_at", "status"]
    ordering = ["title", "-published_at"]
    list_filter = ["status", "published_at", "auther"]
    search_fields = ["title", "content"]
    raw_id_fields = ["auther"]
    date_hierarchy = "published_at"
    prepopulated_fields = {"slug": ("title",)}
    list_editable = ["status"]
    list_display_links = ["auther", "title"]