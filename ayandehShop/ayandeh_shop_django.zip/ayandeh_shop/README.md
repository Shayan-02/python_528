# آینده شاپ | Django Online Shop

پروژه آموزشی فروشگاه اینترنتی با Django، PostgreSQL، Bootstrap 5 و قالب‌های Django.

## امکانات نسخه اول
- صفحه اصلی و دسته‌بندی محصولات
- فهرست و جزئیات محصول
- جستجو، مرتب‌سازی و صفحه‌بندی
- مدیریت محصولات و دسته‌بندی‌ها در Django Admin
- ثبت‌نام، ورود و خروج کاربران
- سبد خرید مبتنی بر Session
- ثبت سفارش و مشاهده سفارش‌های کاربر
- کاهش موجودی هنگام ثبت سفارش با تراکنش دیتابیس

> این نسخه آموزشی است. درگاه پرداخت واقعی، ارسال پیامک، تخفیف پیشرفته و پنل فروشنده در آن پیاده‌سازی نشده‌اند.

## پیش‌نیازها
- Python 3.11 یا بالاتر
- PostgreSQL
- pip

## راه‌اندازی در ویندوز

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

در Linux/macOS:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## تنظیم PostgreSQL
1. در PostgreSQL یک دیتابیس به نام `ayandeh_shop` و یک کاربر بسازید.
2. فایل `.env.example` را به `.env` تغییر نام دهید.
3. مقادیر DB_NAME، DB_USER، DB_PASSWORD، DB_HOST و DB_PORT را تنظیم کنید.
4. SECRET_KEY را با یک مقدار امن جایگزین کنید.

نمونه ساخت دیتابیس در psql:

```sql
CREATE DATABASE ayandeh_shop;
CREATE USER shop_user WITH PASSWORD 'strong-password';
GRANT ALL PRIVILEGES ON DATABASE ayandeh_shop TO shop_user;
```

در نسخه‌های جدید PostgreSQL ممکن است لازم باشد مالکیت دیتابیس را نیز به کاربر اختصاص دهید:

```sql
ALTER DATABASE ayandeh_shop OWNER TO shop_user;
```

## اجرای پروژه

```bash
python manage.py makemigrations products orders
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

سپس:
- فروشگاه: http://127.0.0.1:8000/
- پنل مدیریت: http://127.0.0.1:8000/admin/

## افزودن اطلاعات اولیه
از پنل مدیریت ابتدا چند Category و سپس Product ایجاد کنید. برای هر محصول می‌توانید تصویر، قیمت، موجودی و وضعیت نمایش را تعیین کنید.

## نکات آموزشی و فنی
- قیمت‌ها در این پروژه به تومان و به‌صورت عدد صحیح ذخیره می‌شوند.
- سبد خرید در Session نگهداری می‌شود.
- قیمت و نام محصول هنگام ثبت سفارش در OrderItem کپی می‌شود تا تاریخچه سفارش با تغییرات بعدی محصول عوض نشود.
- برای جلوگیری از فروش بیش از موجودی، ثبت سفارش در transaction.atomic انجام می‌شود و ردیف محصول قفل می‌شود.
- در محیط Production باید DEBUG خاموش، SECRET_KEY امن، HTTPS و تنظیمات Static/Media مناسب فعال شوند.
- قبل از انتشار واقعی، تست‌های خودکار، سیاست بازگشت کالا، درگاه پرداخت و کنترل‌های امنیتی تکمیلی اضافه شوند.

## ساختار پروژه

```text
config/      تنظیمات و URLهای اصلی
core/        صفحه اصلی
products/    دسته‌بندی و محصولات
accounts/    ثبت‌نام و ورود
cart/        سبد خرید Session-based
orders/      ثبت و مشاهده سفارش‌ها
templates/   قالب‌های HTML
static/      فایل‌های CSS و JavaScript
media/       تصاویر آپلودشده
```
